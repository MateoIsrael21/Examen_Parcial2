package edu.ec.com.agroflow.config;

import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    @Bean
    public Exchange cosechasExchange(@Value("${agroflow.events.cosechas.exchange}") String name) {
        return new TopicExchange(name, true, false);
    }
}
