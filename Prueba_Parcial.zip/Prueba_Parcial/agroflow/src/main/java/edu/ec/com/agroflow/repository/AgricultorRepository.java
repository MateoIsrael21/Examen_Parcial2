package edu.ec.com.agroflow.repository;

import edu.ec.com.agroflow.model.Agricultor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface AgricultorRepository extends JpaRepository<Agricultor, UUID> {
    Optional<Agricultor> findByCorreo(String correo);
}
