package edu.ec.com.agroflow.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.UUID;

public class EstadoUpdateRequest {

    @NotBlank
    private String estado; // REGISTRADA / FACTURADA / PAGADA

    private UUID facturaId;

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public UUID getFacturaId() { return facturaId; }
    public void setFacturaId(UUID facturaId) { this.facturaId = facturaId; }
}
