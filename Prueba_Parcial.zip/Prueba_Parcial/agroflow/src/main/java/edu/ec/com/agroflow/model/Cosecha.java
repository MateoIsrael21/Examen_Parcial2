package edu.ec.com.agroflow.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "cosechas")
public class Cosecha {

    @Id
    @GeneratedValue
    @Column(name = "cosecha_id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "agricultor_id", nullable = false)
    private Agricultor agricultor;

    @NotBlank
    @Column(nullable = false, length = 50)
    private String producto;

    @DecimalMin(value = "0.0")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal toneladas;

    @Column(nullable = false, length = 20)
    private String estado = "REGISTRADA";

    @CreationTimestamp
    @Column(name = "creado_en", columnDefinition = "TIMESTAMPTZ")
    private OffsetDateTime creadoEn;

    @Column(name = "factura_id")
    private UUID facturaId;

    // getters y setters

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public Agricultor getAgricultor() { return agricultor; }
    public void setAgricultor(Agricultor agricultor) { this.agricultor = agricultor; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public BigDecimal getToneladas() { return toneladas; }
    public void setToneladas(BigDecimal toneladas) { this.toneladas = toneladas; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public OffsetDateTime getCreadoEn() { return creadoEn; }
    public void setCreadoEn(OffsetDateTime creadoEn) { this.creadoEn = creadoEn; }

    public UUID getFacturaId() { return facturaId; }
    public void setFacturaId(UUID facturaId) { this.facturaId = facturaId; }
}
