package edu.ec.com.agroflow.controller;

import edu.ec.com.agroflow.repository.AgricultorRepository; // <— paquete en minúsculas
import edu.ec.com.agroflow.model.Agricultor;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/agricultores")
public class AgricultorController {

    private final AgricultorRepository repo;

    public AgricultorController(AgricultorRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Agricultor> listar() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Agricultor> obtener(@PathVariable UUID id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Agricultor> crear(@Valid @RequestBody Agricultor body) {
        body.setId(null);
        Agricultor guardado = repo.save(body);
        return ResponseEntity.created(URI.create("/agricultores/" + guardado.getId()))
                .body(guardado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Agricultor> actualizar(@PathVariable UUID id,
                                                 @Valid @RequestBody Agricultor body) {
        return repo.findById(id).map(actual -> {
            actual.setNombre(body.getNombre());
            actual.setFinca(body.getFinca());
            actual.setUbicacion(body.getUbicacion());
            actual.setCorreo(body.getCorreo());
            return ResponseEntity.ok(repo.save(actual));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
