package edu.ec.com.agroflow.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.UUID;

public class CrearCosechaRequest {

    @NotNull
    private UUID agricultorId;

    @NotBlank
    private String producto;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal toneladas;

    @NotBlank
    private String ubicacion;

    public UUID getAgricultorId() { return agricultorId; }
    public void setAgricultorId(UUID agricultorId) { this.agricultorId = agricultorId; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public BigDecimal getToneladas() { return toneladas; }
    public void setToneladas(BigDecimal toneladas) { this.toneladas = toneladas; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
}
