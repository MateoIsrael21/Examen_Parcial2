package edu.ec.com.agroflow.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.annotations.CreationTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "agricultores",
        indexes = { @Index(name = "idx_agricultor_correo", columnList = "correo", unique = true) })
public class Agricultor {

    @Id
    @GeneratedValue
    @Column(name = "agricultor_id", nullable = false, updatable = false)
    private UUID id;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String nombre;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String finca;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String ubicacion;

    @Email
    @NotBlank
    @Column(nullable = false, unique = true, length = 150)
    private String correo;

    @CreationTimestamp
    @Column(name = "fecha_registro", columnDefinition = "TIMESTAMPTZ")
    private OffsetDateTime fechaRegistro;

    // getters y setters

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getFinca() { return finca; }
    public void setFinca(String finca) { this.finca = finca; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public OffsetDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(OffsetDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }
}
