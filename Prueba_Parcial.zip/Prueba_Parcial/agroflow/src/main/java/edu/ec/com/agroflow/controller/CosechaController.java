package edu.ec.com.agroflow.controller;

import edu.ec.com.agroflow.repository.AgricultorRepository;
import edu.ec.com.agroflow.repository.CosechaRepository;
import edu.ec.com.agroflow.dto.CrearCosechaRequest;
import edu.ec.com.agroflow.dto.EstadoUpdateRequest;
import edu.ec.com.agroflow.messaging.EventPublisher;
import edu.ec.com.agroflow.model.Agricultor;
import edu.ec.com.agroflow.model.Cosecha;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/cosechas")
public class CosechaController {

    private final CosechaRepository repo;
    private final AgricultorRepository agricultorRepo;
    private final EventPublisher eventPublisher;

    public CosechaController(CosechaRepository repo,
                             AgricultorRepository agricultorRepo,
                             EventPublisher eventPublisher) {
        this.repo = repo;
        this.agricultorRepo = agricultorRepo;
        this.eventPublisher = eventPublisher;
    }

    @GetMapping
    public List<Cosecha> listar() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cosecha> obtener(@PathVariable UUID id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody CrearCosechaRequest req) {
        Optional<Agricultor> maybeAg = agricultorRepo.findById(req.getAgricultorId());
        if (!maybeAg.isPresent()) { // <- compatible con Java < 11
            return ResponseEntity.badRequest().body("Agricultor no existe: " + req.getAgricultorId());
        }

        Cosecha c = new Cosecha();
        c.setAgricultor(maybeAg.get());
        c.setProducto(req.getProducto());
        c.setToneladas(req.getToneladas() == null ? BigDecimal.ZERO : req.getToneladas());
        c.setEstado("REGISTRADA");

        Cosecha guardada = repo.save(c);

        eventPublisher.publicarNuevaCosecha(
                guardada.getId(),
                guardada.getProducto(),
                guardada.getToneladas().doubleValue()
        );

        return ResponseEntity.created(URI.create("/cosechas/" + guardada.getId()))
                .body(guardada);
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<?> actualizarEstado(@PathVariable UUID id,
                                              @Valid @RequestBody EstadoUpdateRequest req) {
        return repo.findById(id).map(c -> {
            c.setEstado(req.getEstado());
            if (req.getFacturaId() != null) c.setFacturaId(req.getFacturaId());
            return ResponseEntity.ok(repo.save(c));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
